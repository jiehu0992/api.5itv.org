<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title></title>
</head>

<body topmargin="0" leftmargin="0" bgcolor="#000000" scroll="no">
<embed id="flash-player" class="flash-player" width="100%" height="100%" type="application/x-shockwave-flash" src="http://resource.ws.kukuplay.com/plugins/fengyun2.1.swf" allowFullScreenInteractive="true" allowfullscreen="true" allowscriptaccess="always" quality="high" cachebusting="true" wmode="Transparent" bgcolor="#000000" pluginspage="http://get.adobe.com/cn/flashplayer/" flashvars="config="/>
                                    
</body>

</html>
