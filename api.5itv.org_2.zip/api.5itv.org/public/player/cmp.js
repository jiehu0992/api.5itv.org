(function(a){typeof a.CMP=="undefined"&&(a.CMP=function(){var b=/msie/.test(navigator.userAgent.toLowerCase()),c=function(a,b){if(b&&typeof b=="object")for(var c in b)a[c]=b[c];return a},d=function(a,d,e,f,g,h,i){i=c({width:d,height:e,id:a},i),h=c({allowfullscreen:"true",allowscriptaccess:"always"},h);var j,k,l,m=[];if(g){if(typeof g=="object"){for(l in g)m.push(l+"="+encodeURIComponent(g[l]));j=m.join("&")}else j=String(g);h.flashvars=j}k="<object ",k+=b?'classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,0,0,0" ':'type="application/x-shockwave-flash" pluginspage="http://www.adobe.com/go/getflashplayer" data="'+f+'" ';for(l in i)k+=l+'="'+i[l]+'" ';k+=b?'><param name="movie" value="'+f+'" />':">";
for(l in h)k+='<param name="'+l+'" value="'+h[l]+'" />';
k+="</object>";return k},e=function(c){var d=document.getElementById(String(c));
if(!d||d.nodeName.toLowerCase()!="object")d=b?a[c]:document[c];
return d},f=function(a){if(a){for(var b in a)typeof a[b]=="function"&&(a[b]=null);
a.parentNode.removeChild(a)}},g=function(a){if(a){var c=typeof a=="string"?e(a):a;
if(c&&c.nodeName=="OBJECT"){b?(c.style.display="none",function(){c.readyState==4?f(c):setTimeout(arguments.callee,15)}()):c.parentNode.removeChild(c);return!0}}return!1};
return{create:function(){return d.apply(this,arguments)},write:function(){var a=d.apply(this,arguments);document.write(a);
return a},get:function(a){return e(a)},remove:function(a){return g(a)}}}())})(window);
//wmp配置
if(typeof window.WMP==="undefined") {
	var WMP=window.WMP=new (function(){
		var key,cmpo,wmpo,display,wmping;
		this.init=function(_key, _cmpo){
			if (!cmpo) {
				key = _key;
				cmpo = _cmpo;
				cmpo.addEventListener("model_start", "WMP.update");
				cmpo.addEventListener("model_state", "WMP.update");
				cmpo.addEventListener("resize", "WMP.update");
				cmpo.addEventListener("control_fullscreen", "WMP.mini");
			}
		};
		this.update = function(data) {
			display = false;
			wmping = false;
			var item = cmpo.item();
			if (item) {
				if (item.type == "wmp") {
					if (!wmpo) {
						wmpo = $("WMP_" + key);
						if (wmpo) {
							wmpo.uiMode = "None";
							wmpo.fullScreen = false;
							wmpo.stretchToFit = true;
							wmpo.enableContextMenu = true;
							wmpo.style.top = "0px";
							wmpo.style.left = "0px";
							wmpo.style.position = "absolute";
							cmpo.parentNode.appendChild(wmpo);
						}
					}
					var state = cmpo.config("state");
					if (state == "playing") {
						wmping = true;
						var is_show = cmpo.skin("media", "display");
						if (is_show) {
							display = true;		
						}
					}
				}
			}
			wmpo.style.visibility = display ? "visible" : "hidden";
			if (display) {
				var tx = 0;
				var ty = 0;
				if (!cmpo.config("video_max")) {
					tx = parseInt(cmpo.skin("media", "x")) + parseInt(cmpo.skin("media.video", "x"));
					ty = parseInt(cmpo.skin("media", "y")) + parseInt(cmpo.skin("media.video", "y"));
				}
				var tw = cmpo.config("video_width");
				var th = cmpo.config("video_height");
				wmpo.style.top = ty + "px";
				wmpo.style.left = tx + "px";
				wmpo.width = tw;
				wmpo.height = th;
			}
		}
		this.fullscreen = function(data) {
			var item = cmpo.item();
			if (item.type == "wmp" && wmping) {
				var fullscreen = cmpo.config("fullscreen");
				if (fullscreen) {
					cmpo.sendEvent("view_fullscreen");
					wmpo.fullScreen = true;
				}
			}
		}
	})();
}