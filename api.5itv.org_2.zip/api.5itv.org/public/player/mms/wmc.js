switch (newstate) 
{ 
            case 1: 
                        $("dStatus").innerHTML = "停止"; 
                        break; 
            case 2: 
                        $("dStatus").innerHTML = "暂停"; 
                        break; 
            case 3: 
                        $("dStatus").innerHTML = "正在播放"; 
                        break; 
            case 4: 
                        $("dStatus").innerHTML = "4"; 
                        break; 
            case 5: 
                        $("dStatus").innerHTML = "5"; 
                        break; 
            case 6: 
                        $("dStatus").innerHTML = "正在缓冲..."; 
						setInterval("updatetime()",100);
                        break; 
            case 7: 
                        $("dStatus").innerHTML = "7"; 
                        break; 
            case 8: 
                        $("dStatus").innerHTML = "8"; 
                        break; 
            case 9: 
                        $("dStatus").innerHTML = "正在连接..."; 
                        break; 
            case 10: 
                        $("dStatus").innerHTML = "<font color=red>无法连接</font>"; 
                        break; 
            case 11: 
                        $("dStatus").innerHTML = "11"; 
                        break; 
            default: 
                        $("dStatus").innerHTML = "正在连接..."; 
} <!--
 
if (window.Event) 
  document.captureEvents(Event.MOUSEUP); 
 
function nocontextmenu() 
{
 event.cancelBubble = true
 event.returnValue = false;
 
 return false;
}
 
function norightclick(e) 
{
 if (window.Event) 
 {
  if (e.which == 2 || e.which == 3)
   return false;
 }
 else
  if (event.button == 2 || event.button == 3)
  {
   event.cancelBubble = true
   event.returnValue = false;
   return false;
  }
 
}
 
document.oncontextmenu = nocontextmenu;  // for IE5+
document.onmousedown = norightclick;  // for all others
//-->
