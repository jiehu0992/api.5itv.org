function updatetime() 
{ 
       $("dStatus").innerHTML = "加载中.." + MediaPlayer.network.BufferingProgress +"%"; 
	   if ( MediaPlayer.network.BufferingProgress == 100 ){clearInterval();$("dStatus").innerHTML = "播放中";}
} 
function $($){return document.getElementById($)}
function imgDoPlay_onclick(){
	imgDoPlay=$("playA");
	imgDoPause=$("pauseA");
	if(imgDoPause.style.display=="block"){
		MediaPlayer.controls.Stop();
		if(imgDoPause)imgDoPause.style.display="none";
		if(imgDoPlay)imgDoPlay.style.display="block";
		$("dStatus").innerHTML="\u5df2\u505c\u6b62"
	}
	else{
		MediaPlayer.controls.Play();
		if(imgDoPause)imgDoPause.style.display="block";
		if(imgDoPlay)imgDoPlay.style.display="none"
	}
}
function imgDoMute_onclick(){
	$("voxA").style.display="none";
	$("voxB").style.display="block";
	MediaPlayer.settings.mute=true;
}
function unMute(){
	$("voxA").style.display="block";
	$("voxB").style.display="none";
	MediaPlayer.settings.mute=false;
}
function wmplay(src){
   
   if (src==''||src==null||src=='undefined'){
	 document.write('未设置播放源!');   return;
   }

document.writeln("<object classid=\"clsid:6BF52A52-394A-11d3-B153-00C04F79FAA6\" codebase='http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=6,4,5,715'  width=\"100%\" height=\"95%\" align=\"middle\" Id=\"MediaPlayer\" name=\"MediaPlayer\">");
document.writeln("<param name=\"autoStart\" value=\"-1\">");
document.writeln("<param name=\"rate\" value=\"1\">");
document.writeln("<param name=\"invokeURLs\" value=\"-1\">");
document.writeln("<param name=\"volume\" value=\"100\">");
document.writeln("<param name=\"mute\" value=\"0\">");
document.writeln("<param name=\"uiMode\" value=\"none\">");
document.writeln("<param name=\"stretchToFit\" value=\"-1\">");
document.writeln("<param name=\"windowlessVideo\" value=\"-1\">");
document.writeln("<param name=\"enabled\" value=\"-1\">");
document.writeln("<param name=\"enableContextMenu\" value=\"0\">");
document.writeln("<param name=\"fullScreen\" value=\"0\">");
document.writeln("<param name=\"enableErrorDialogs\" value=\"0\">");
document.writeln("<param name=\"URL\" value=\"" + src + "\">");
document.writeln("<\/object>");
document.writeln("<div id=\"playClavier\">");
document.writeln("<div id=\"playA\" style=\"display:none;\"><a class=\"imgPlay\" title=\"播放\" href=\"javascript:void(0);\" onClick=\"imgDoPlay_onclick();\"></a></div>");
document.writeln("<div id=\"pauseA\" style=\"display:block;\"><a class=\"imgPause\" title=\"暂停\" href=\"javascript:void(0);\" onClick=\"imgDoPlay_onclick();\"></a></div>");
document.writeln("<div class=\"ll\"></div>");
document.writeln("<div id=\"voxA\" style=\"display:block;\"><a class=\"imgmute\" title=\"静音\" href=\"javascript:void(0);\" onClick=\"imgDoMute_onclick()\"></a></div>");
document.writeln("<div id=\"voxB\" style=\"display:none;\"><a class=\"imgUnMute\" title=\"取消静音\" href=\"javascript:void(0);\" onClick=\"unMute()\"></a></div>");
document.writeln("<div class=\"ll\"></div>");
document.writeln("<div id=\"logo\"><span id=\"dStatus\"></span><span id=\"advtext\"></span></div>");
document.writeln("<div id=\"spreadA\"><a class=\"imgFullScreen\" title=\"全屏\" href=\"javascript:void(0);\" onClick=\"setfullscreen();\"></a></div>");
document.writeln("<div id=\"tvguide\"><a class=\"imgMenu\" title=\"麻麻视听\" href=\"http://wltv.ucoz.com/wltv/tv.htm\" target=\"_blank\"></a></div>");
document.writeln("<div id=\"voxSlider\" style=\"width:70px;\"></div>");
document.writeln("</div>");

}