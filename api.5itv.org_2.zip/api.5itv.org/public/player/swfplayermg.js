function swfplay(src){
document.writeln("<embed src=\""+src+"\" quality=\"high\" wmode=\"transparent\" width=\"100%\" height=\"100%\" type=\"application/x-shockwave-flash\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" allowfullscreen=\"true\" allowscriptaccess=\"always\"><\/embed>");
}