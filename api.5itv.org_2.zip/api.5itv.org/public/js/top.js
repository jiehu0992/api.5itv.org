function showzk(){
        list.style.display = "block";
        zk.style.display = "none";
        sh.style.display = "block";
     }
function showsh(){
        list.style.display = "none";
        zk.style.display = "block";
        sh.style.display = "none";
     }