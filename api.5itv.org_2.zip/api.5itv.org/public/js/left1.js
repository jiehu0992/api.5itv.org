function showzk(){
        menubox.style.display = "block";
        zk.style.display = "none";
        sh.style.display = "block";
        playbox.style.left="202px";
     }

function showsh(){
        menubox.style.display = "none";
        zk.style.display = "block";
        sh.style.display = "none";
        playbox.style.left="7px";
     }