function showsh(){
  list.style.display = "none";
  zklist.style.display = "block";     
  shlist.style.display = "none";
  playbox.style.right="7px";
}
     
function showzk(){
  list.style.display = "block";
  zklist.style.display = "none";
  shlist.style.display = "block";
  playbox.style.right="202px";
}
     
function showtq(){
  tqbox.style.display="block"
}

function hidddnsh(){
  tqbox.style.display="none"
}