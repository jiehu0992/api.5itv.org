var tvurl=window.location.href.split('id=')[1];
if(tvurl=="ahws"){
src1='http://zbbf2.ahtv.cn/live/749.flv';
src2='http://zbbf2.ahtv.cn/live/749.m3u8';
}

if(tvurl=="ahjj"){
src1='http://zbbf2.ahtv.cn/live/750.flv';
src2='http://zbbf2.ahtv.cn/live/750.m3u8';
}

if(tvurl=="ahgg"){
src1='http://zbbf2.ahtv.cn/live/752.flv';
src2='http://zbbf2.ahtv.cn/live/752.m3u8';
}

if(tvurl=="ahkj"){
src1='http://zbbf2.ahtv.cn/live/754.flv';
src2='http://zbbf2.ahtv.cn/live/754.m3u8';
}

if(tvurl=="ahys"){
src1='http://zbbf2.ahtv.cn/live/756.flv';
src2='http://zbbf2.ahtv.cn/live/756.m3u8';
}

if(tvurl=="ahzy"){
src1='http://zbbf2.ahtv.cn/live/758.flv';
src2='http://zbbf2.ahtv.cn/live/758.m3u8';
}

if(tvurl=="ahrw"){
src1='http://zbbf2.ahtv.cn/live/da9.flv';
src2='http://zbbf2.ahtv.cn/live/da9.m3u8';
}

if(tvurl=="ahgj"){
src1='http://zbbf2.ahtv.cn/live/dab.flv';
src2='http://zbbf2.ahtv.cn/live/dab.m3u8';
}

document.write('<div id="list" style="display:none;">');
        document.write('<a id="xl1" href="../tc.html?id='+src1+'">FLV线路</a>');
        document.write('<a id="xl2" href="../dp.html?id='+src2+'">M3U8线路</a>');
document.write('</div><div id="zk" onclick="showzk()"></div><div id="sh" onclick="showsh()" style="display:none;"></div><div id="playbox">')
document.write('<iframe name="ahxl" src="../tc.html?id='+src1+'" height="100%" width="100%" scrolling="no" border="0" frameborder="0"></iframe>');
document.write('</div>');
